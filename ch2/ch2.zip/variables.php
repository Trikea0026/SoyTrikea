<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Variables</title>
</head>
<body>
<?php 
// An address:
$street = "100 Main Street";
$city = "State College";
$state = "PA";
$zip = 16801;
// Print the address:
print "<p>The address is:<br>$street <br>$city $state $zip</p>";
?>
</body>
</html>