<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Variables and Comments</title>
</head>
<body>
<?php 
// Define my variables....
$year = 2020; // The current year.
$june_avg = 88; // The average temperature for the month of June.
$page_title = 'Weather Reports'; // A title for the page.
echo "Year: $year Jone Avg:$june_avg Title:$page_title.</br>";
echo 'Year: $year Jone Avg:$june_avg Title:$page_title.</br>';
print "Year: $year Jone Avg:$june_avg Title:$page_title.</br>";
print 'Year: $year Jone Avg:$june_avg Title:$page_title.</br>';
?>
</body>
</html>
