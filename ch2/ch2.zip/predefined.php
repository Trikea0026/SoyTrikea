<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Predefined Variables</title>
</head>
<body>
<pre>
<?php  
// Show the value of the $_SERVER variable:
print_r($_SERVER);
print "print </br>";
printf("printf </br>");
echo "echo </br>";
?>
</pre>
</body>
</html>